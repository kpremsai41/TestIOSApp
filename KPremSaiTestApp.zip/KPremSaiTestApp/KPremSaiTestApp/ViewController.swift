//
//  ViewController.swift
//  KPremSaiTestApp
//
//  Created by K Prem Sai on 2/11/20.
//  Copyright © 2020 Sample. All rights reserved.
//

import UIKit

class ViewController: UITableViewController {
    
    var rowsFeed = [Rowsfeed]()

    override func viewDidLoad() {
        super.viewDidLoad()
       
        self.fetchJson()
    }

    func fetchJson() {
        
        let urlString = "https://dl.dropboxusercontent.com/s/2iodh4vg0eortkl/facts.json"
        
        let url = URL(string: urlString)
        
        guard url != nil else {
            return
        }
        
        let session = URLSession.shared
        
        let dataTask = session.dataTask(with: url!) { (data, response, error) in
            
            // Check for errors
            if error == nil && data != nil {
                
                // Parse Json
                let decoder = JSONDecoder()
                
                do {
                    let feeding = try decoder.decode(JSONFeed.self, from: data!)
                    print(feeding)
                }
                catch {
                    print("Error in JSON parsing!")
                }
            }
        }
        
        // Make the API call
        dataTask.resume()
    }

}

extension ViewController {
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return rowsFeed.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let rowFedding = rowsFeed[indexPath.row]
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        cell.textLabel?.text = rowFedding.title
        cell.detailTextLabel?.text = rowFedding.description
        return cell
    }
}
