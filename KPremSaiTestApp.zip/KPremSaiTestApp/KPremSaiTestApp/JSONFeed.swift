//
//  Feed.swift
//  KPremSaiTestApp
//
//  Created by K Prem Sai on 2/11/20.
//  Copyright © 2020 Sample. All rights reserved.
//

import Foundation

struct JSONFeed: Codable {
    var title: String = ""
    var rows: [Rowsfeed]
}
